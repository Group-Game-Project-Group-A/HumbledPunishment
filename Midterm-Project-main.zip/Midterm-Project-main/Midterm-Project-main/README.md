Midterm Project

The Project is a 2D Dungeon Crawler with roguelike and exploration type gameplay elements.
